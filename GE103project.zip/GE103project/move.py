import pygame
from piece import pieces
from piece import boards


class move:

    def piece_capture(wl,bl,x_new,y_new):
        pass

    def move_piece(objbrd,board,piece,row,column,chance):
        '''
        It takes the board representation the piece to
         move and the position
        where it has to
        move...then it moves the
        position of piece to
        the respective position
        If it is the last  position it changes
        it to  the king piece and it kills
        any piece in between
        '''
        row_for_board=row-1
        column_for_board=column-1
        valid_moves=objbrd.valid_moves(piece)

        if(chance==piece.color):
            if (column_for_board, row_for_board) in valid_moves:
                piece.row = row
                piece.column = column
                piece.xy_updater()
                delete_piece = valid_moves[column_for_board, row_for_board]

                if(type(delete_piece[0])==list):
                    if (len(delete_piece[0]) == 0):
                        pass
                    else:
                        delete_piece[0][0].exist = 0
                if(type(delete_piece[0])!=list):
                    delete_piece[0].exist = 0


                if (piece.color == 'w' and piece.column == 8):
                    piece.type = 'k'
                    piece.picture = pygame.image.load('white_king.png')
                    piece.picture = pygame.transform.scale(piece.picture, (40, 40))
                    piece.playerImg = piece.picture

                if (piece.color == 'b' and piece.column == 1):
                    piece.type = 'k'
                    piece.picture = pygame.image.load('black_king.png')
                    piece.picture = pygame.transform.scale(piece.picture, (40, 40))
                    piece.playerImg = piece.picture
                for i in range(len(board)):
                    for j in range(len(board[0])):
                        if (board[i][j] == piece):
                            board[i][j], board[row - 1][column - 1] = board[row - 1][column - 1], board[i][j]
                chance=boards.turn(chance)
        return chance



    def score(self,wl,bl):
        score=len(wl)-len(bl)
        for i in wl:
            if(i.type=='k'):
                score+=0.5
        for i in bl:
            if(i.type=='k'):
                score+=0.5

        return score


