
import pygame

import piece
from piece import pieces
from piece import boards
from move import move




#initialization
'''
The background image contains the image we are going to apply
In the background
The screen window will be 700×700 size
 Each square is of 40×40 dimension
 '''
#The pygame is initialized here
pygame.init()
screen=pygame.display.set_mode((700,700))
pygame.display.set_caption("Checkers")
bg_img = pygame.image.load('background.jpg')
bg_img = pygame.transform.scale(bg_img,(700,700))
pygame.init()
font=pygame.font.SysFont('Times New Roman',40,True,False)





#player
'''
There are 12white pieces which are initialized and stored in white list and 
similar process has been done for black pieces
Board positions has the representation of the board
'''
wp1=pieces(1,1,'w',screen,1)
wp2=pieces(3,1,'w',screen,1)
wp3=pieces(5,1,'w',screen,1)
wp4=pieces(7,1,'w',screen,1)
wp5=pieces(2,2,'w',screen,1)
wp6=pieces(4,2,'w',screen,1)
wp7=pieces(6,2,'w',screen,1)
wp8=pieces(8,2,'w',screen,1)
wp9=pieces(1,3,'w',screen,1)
wp10=pieces(3,3,'w',screen,1)
wp11=pieces(5,3,'w',screen,1)
wp12=pieces(7,3,'w',screen,1)
white_list=[wp1,wp2,wp3,wp4,wp5,wp6,wp7,wp8,wp9,wp10,wp11,wp12]





bp1=pieces(8,8,'b',screen,1)
bp2=pieces(6,8,'b',screen,1)
bp3=pieces(4,8,'b',screen,1)
bp4=pieces(2,8,'b',screen,1)
bp5=pieces(1,7,'b',screen,1)
bp6=pieces(3,7,'b',screen,1)
bp7=pieces(5,7,'b',screen,1)
bp8=pieces(7,7,'b',screen,1)
bp9=pieces(2,6,'b',screen,1)
bp10=pieces(4,6,'b',screen,1)
bp11=pieces(6,6,'b',screen,1)
bp12=pieces(8,6,'b',screen,1)
black_list=[bp1,bp2,bp3,bp4,bp5,bp6,bp7,bp8,bp9,bp10,bp11,bp12]
#we created a combined list which contains black and white list
combined_list=white_list+black_list

chance='b'
#Game loop
running =1

chance='b'
clock=pygame.time.Clock()
position_on_board = boards.board_position(combined_list, screen)
while running:
    '''
     we run a while loop contiously to run the game and it will 
     stop running whenever we hit the close button with the screen being 
     constinously updated 
    '''

    position_on_board = boards.board_position(combined_list, screen)
    brd = boards(screen,position_on_board)
    screen.fill((0, 175, 0))
    screen.blit(bg_img, (0, 0))
    brd.draw_board(screen)

    # screen is placed first because we want to draw the player on fill
    for i in white_list:
        i.player(screen)

    for i in black_list:
        i.player(screen)

    position_on_board=boards.board_position(combined_list,screen)

    #to check if someone rage quit as it ain't that easy to beat us
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running=0


    if (event.type==pygame.MOUSEBUTTONDOWN and event.button==1):
        pos=pygame.mouse.get_pos()
        x,y=boards.position_mouse(pos)
        piece_in_consideration=boards.get_piece(position_on_board,screen,x,y)
        #print(brd.valid_moves(piece_in_consideration))
        if piece_in_consideration is None:
            continue



    if (event.type == pygame.MOUSEBUTTONDOWN and event.button==3 ):
        new_pos = pygame.mouse.get_pos()
        x_new, y_new = boards.position_mouse(new_pos)
        if(x_new>8 or y_new>8 or x_new<1 or y_new<1):
            continue
        if(piece_in_consideration==None):
            continue
        chance=move.move_piece(brd,position_on_board, piece_in_consideration, x_new, y_new,chance)


    pygame.display.update()
