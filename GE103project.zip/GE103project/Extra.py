
def check_win(wl,bl):
    valid_moves_white=[]
    valid_moves_black=[]
    if(len(wl)==0):
        return 'Black win'

    if(len(bl)==0):
        return 'White win'


    elif(len(valid_moves_black)==0 ):
        return 'White Win'

    elif(len(valid_moves_white)==0):
        return 'Black Win'

    else:
        return 'Game on'



'''
    def valid_moves(board, piece):
        killed = []
        possible_places = []

        if (piece.color == 'w' or piece.type == 'k'):
            if (piece.column == 8):
                pass
            else:
                if(piece.row==8):
                    pass
                elif (board[piece.column][piece.row].exist == 0):
                    possible_places += [[(piece.column,piece.row)]]

                if(piece.row==1):
                   pass

                elif (board[piece.column][piece.row - 2].exist == 0):
                    possible_places += [[(piece.column,piece.row - 2)]]

        if (piece.color == 'b' or piece.type == 'k'):
            if (piece.column == 1):
                pass

            else:
                if(piece.row==8):
                    pass
                elif (board[piece.column - 2][piece.row].exist == 0):
                    possible_places += [[(piece.column - 2,piece.row)]]
                elif (piece.column == 8):
                    pass
                elif (board[piece.column - 2][piece.row - 2].exist == 0):
                    possible_places += [[(piece.column - 2,piece.row - 2)]]

        return possible_places

    def valid_kill_moves(board,piece,valid_list):
        moves=[]
        if (piece.color == 'w' or piece.type == 'k'):
            if (piece.column == 8 or piece.column==7):
                pass
            else:
                if (piece.row == 8 or piece.row==7):
                    pass
                elif (board[piece.column][piece.row].exist == 1 and board[piece.column][piece.row].color == 'b' and board[piece.column+1][piece.row+1].exist==0):
                    if (piece.column+1, piece.row+1) not in valid_list[len(valid_list)-1]:
                        moves += [(piece.column+1, piece.row+1)]

                if (piece.row == 1 or piece.row==2):
                    pass

                elif (board[piece.column][piece.row - 2].exist == 1 and board[piece.column][piece.row - 2].color == 'b' and board[piece.column+1][piece.column-3].exist==0):
                    moves += [(piece.column, piece.row - 2)]

        if (piece.color == 'b' or piece.type == 'k'):
            if (piece.column == 1 or piece.column==2):
                pass

            else:
                if (piece.row == 1 or piece.row==2):
                    pass
                elif (board[piece.column - 2][piece.row].exist == 1 and board[piece.column - 2][piece.row].color == 'w' and board[piece.column - 3][piece.row+1].exist==0):
                    moves += [(piece.column - 2, piece.row)]
                if (piece.row == 1 or piece.column == 1):
                    pass
                elif (board[piece.column - 2][piece.row - 2].exist == 1 and board[piece.column - 2][piece.row - 2].color == 'w' and board[piece.column - 3][piece.row - 3].exist == 0):
                    moves += [(piece.column - 2, piece.row - 2)]

            if(len(moves)==0):
                valid_list+=moves
                return valid_list
            else:
                valid_list+=[valid_list+board.valid_kill_moves(board,piece,valid_list)]
'''




