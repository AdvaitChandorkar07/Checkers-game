from copy import deepcopy
import pygame

class algorithm:
    def minmax(board,depth,min_or_max,):
        pass