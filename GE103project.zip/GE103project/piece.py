import pygame
class pieces:

    def __init__(self,x_coordinate,y_coordinate,colour,screen,bool):
        '''
        X and yccoordinates are the positions on
        the screen whereas row and column
        contain the position of pieces on
        the board If the value of Exist
        is zero, it means there
        's a blank piece and if it's
        value is 1, it implies there
        's a piece present which the player can move.
        Type defines if it's a normal piece or king.
        Color defines if it's the black
        player or white one.
        Picture stores the location of pieces
        '''
        self.exist=bool
        self.x=200+(x_coordinate-1)*40
        self.y=200+(y_coordinate-1)*40
        self.row=x_coordinate
        self.column=y_coordinate
        self.type='n'
        self.color=colour
        if(self.color=='w'):
            self.picture = pygame.image.load('white_piece.png')
            self.picture = pygame.transform.scale(self.picture, (40,40))
            self.playerImg=self.picture

        else:
            self.picture = pygame.image.load('black_piece.png')
            self.picture = pygame.transform.scale(self.picture, (40,40))
            self.playerImg=self.picture


    def piece_printer(self,x1,y1,c):
        pass



    def player(self,screen):
        '''
        Used to print individual pieces in board which are called one by one
        '''
        global x,y,playerImg
        if(self.exist==1):
            screen.blit(self.playerImg,(self.x,self.y))


    def xy_updater(self):
        '''Used to update the x and y coordinates'''
        self.x=200+(self.row-1) * 40
        self.y = 200 + (self.column - 1) * 40





#######################################################################
class boards:
    def __init__(self,screen,position_on_board):
        self.screen=screen
        self.board = position_on_board
    
    def draw_square(self,screen,x,y,c):
        '''
        Use for drawing board squares
        '''
        if(c==-1):
            pygame.draw.rect(screen,'black',[x,y,40,40])
        else:
            pygame.draw.rect(screen, 'yellow', [x, y, 40, 40])

    def remove_piece(self, killed):
        for i in killed:
            i.exist=0

    def draw_board(self,screen):
        '''It basically prints the squares taking in x
        and y coordinates
        and goes x coordinate to x+ 40 coordinate and y
         y +40 coordinate
         '''


        x = 200
        y = 200
        c=1
        for i in range(8):
            for j in range(8):
                self.draw_square(screen,x, y,c)
                x += 40
                c*=-1
            y += 40
            x=200
            c*=-1

    def position_mouse(pos):
        '''
        Used to find the row and column where the mouse is present
        '''
        x, y = pos
        row = int((x - 200) / 40 + 1)
        col = int((y - 200) / 40 + 1)
        return (row, col)

    def get_piece(board,screen,x,y):
        for i in range(len(board)):
            for j in range(len(board[0])):
                if(board[i][j].exist==1):
                    if(board[i][j].row==x and board[i][j].column==y):
                        return board[i][j]


    #def move_piece(piece,x_new,y_new,screen):


    def board_position(combined_list,screen):
        '''It forms a 2 dimensional list which has the position of each piece
        on the board where first index is column and second index is the column
        '''


        board=[[0 for i in range(8)] for j in range(8)]
        for i in combined_list:
            board[i.column-1][i.row-1]=i
        for i in range(len(board)):
            for j in range(len(board[i])):
                if(board[i][j]==0):
                    board[i][j]=pieces(j+1,i+1,'b',screen,0)

        return board



    def valid_moves(self,piece):
        moves={}
        row=piece.column-1

        '''
        if(row<3):
            row=row+3
        else:
            row=row-3
        if(column<3):
            column=column+3
        else:
            column=column-3
        '''
        left=piece.row-2
        right=piece.row
        #the king piece has the power to move in both the directions
        # So we consider it in both cases of w and b
        if(piece.color=='b' or piece.type=='k'):
            #The piece will only move in diogonal direction so we check in the left diogonal
            #so we check it in both directions 
            moves.update(self._left_diagonal(row-1,max(piece.column-4,-1),-1,piece.color,left))
            moves.update(self._right_diagonal(row - 1, max(piece.column - 4, -1), -1, piece.color, right))

        if(piece.color == 'w' or piece.type == 'k'):
            moves.update(self._left_diagonal(row + 1, min(row + 3, 8), 1, piece.color, left))
            moves.update(self._right_diagonal(row + 1, min(row + 3, 8), 1,piece.color, right))
        return moves

    def _left_diagonal(self,start,stop,step,color,left,skipped=[]):
        #moves is a dictionary which has the possible moves as index
        #and the pieces we kill are
        moves={}
        last=[]
        for i in range(start,stop,step):
            if left<0:
                break
            if(left==8):
                #To keep the piece on the board
                current_piece= self.board[i][left-1]
            else:
                #we find the current piece we are on
                current_piece = self.board[i][left]
            if current_piece.exist==0:
                if skipped and not last:
                    #if we skipped and there is no more moves left
                    break
                elif skipped:
                    #we have double jumped so we combine last checker with the current one
                    moves[(i,left)]= [last , skipped]
                else:
                    #it's our first move we will have the left diogonal
                    moves[(i,left)]=[last]

                if last:
                    # if we skipped and there is no more moves left
                    if step==-1:
                        row=max(i-3,0)
                    else:
                        row=min(i+3,8)
                    #After we kill a piece we will again check both the diogonals if we can kill more pieces
                    moves.update(self._left_diagonal(i + step,row,step,color,left-1 ,skipped=[last]))
                    moves.update(self._left_diagonal(i + step, row, step,color, left+1,skipped=[last]))
                    #We break as we can't make normal moves after we do kill moves
                break
            elif (current_piece.color==color and current_piece.exist==1):
                #If there is a  piece of the same colour on the diogonal
                # we want make any possible moves so we break
                break
            else:
                #we now u[date the last to current piece
                last=current_piece
                #then we move along the diogoal
            left-=1
        return moves







    def _right_diagonal(self,start,stop,step,color,right,skipped=[]):
        moves = {}
        last = []
        for i in range(start, stop, step):
            if right >= 8:
                # To keep the piece on the board
                break
            current_piece = self.board[i][right]
            if current_piece.exist == 0:
                if skipped and not last:
                    # if we skipped and there is no more moves left
                    break
                elif skipped:
                    # we have double jumped so we combine last checker with the current one
                    moves[(i, right)] = [last,skipped]
                else:
                    moves[(i, right)] = [last]

                if last:
                    if step == -1:
                        row = max(i - 3, 0)
                    else:
                        # it's our first move we will have the left diogonal
                        row = min(i + 3, 8)
                    # After we kill a piece we will again check both the diogonals if we can kill more pieces
                    moves.update(self._left_diagonal(i + step, row, step,color, right - 1, skipped=[last]))
                    moves.update(self._left_diagonal(i + step, row, step,color, right + 1, skipped=[last]))
                    # We break as we can't make normal moves after we do kill moves
                break
            elif (current_piece.color == color and current_piece.exist == 1):
                # If there is a  piece of the same colour on the diogonal
                # we want make any possible moves so we break
                break
            else:
                # we now u[date the last to current piece
                last = [current_piece]
                # we find the current piece we are on
            right+=1
            # then we move along the diogoal
        return moves

    def turn(change):
        if change== 'w':
            change='b'
        else:
            change='w'
        return change


