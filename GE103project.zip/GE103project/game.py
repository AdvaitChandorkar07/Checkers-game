import pygame
from piece import pieces
from piece import board
from move import move


class game:
    def __init__(self,screen):
        self.screen=screen
        self.selected=None
        self.board=board
        self.turn='b'
        self.valid_moves={}

    def update(self):
        board.draw_board(self.screen)
        pygame.display.update()

